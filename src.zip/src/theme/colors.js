export const colors = {
  bg: '#0f2a2d',
  card: '#20353b',
  input: '#e5e7eb',
  text: '#e8edf1',
  sub: '#c3cbd2',
  btn: '#1f2937',
  btnText: '#ffffff',
  shadow: 'rgba(0,0,0,0.25)'
};
